-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- PORT: 80
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

--
-- Database: `service_center`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(8) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `username`, `password`, `name`, `phone`, `address`) VALUES
(1, 'sorabh', 'sorabh', 'Sorabh Sharma', '349-834-3959', 'D-Block, Flat 23, Delhi'),
(2, 'admin', 'admin', 'John Smith', '3498343959', '555 Main Street'),
(3, 'ramasankar', 'ramasankar', 'ramasankar', '943857434', '2134 Street'),
(4, 'monica', 'monica', 'Monica Kumari', '3498343959', '123, Main street');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(8) NOT NULL,
  `customer_id` int(8) NOT NULL,
  `device_category_id` int(8) NOT NULL,
  `brand_name` varchar(255) NOT NULL,
  `serial_no` varchar(255) NOT NULL,
  `purchase_price` decimal(8,2) NOT NULL,
  `date_of_purchase` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `customer_id`, `device_category_id`, `brand_name`, `serial_no`, `purchase_price`, `date_of_purchase`) VALUES
(1, 1, 9, 'LG', 'L34254', '5000.00', '2005-01-02'),
(3, 2, 6, 'SONY', 'S3343', '8000.00', '2013-01-31'),
(4, 1, 3, 'Okinava', 'OKI4551', '8499.00', '2014-05-28'),
(5, 4, 11, 'Whirlpool', 'W93484', '8790.00', '2010-02-05'),
(6, 4, 11, 'Godrej 7 kg', 'G3465', '18840.00', '2011-03-05'),
(7, 1, 11, 'Okinavas', '34kdjf', '343.00', '1998-03-09'),
(8, 1, 5, 'SONY', 'DS4384', '3883.00', '1999-09-08');

-- --------------------------------------------------------

--
-- Table structure for table `device_category`
--

CREATE TABLE `device_category` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_category`
--

INSERT INTO `device_category` (`id`, `name`) VALUES
(3, 'Refrigerator'),
(4, 'Air Conditioners'),
(5, 'Air Coolers'),
(6, 'Microwave Ovens'),
(9, 'TV'),
(11, 'Washing Machine');

-- --------------------------------------------------------

--
-- Table structure for table `device_parts`
--

CREATE TABLE `device_parts` (
  `id` int(11) NOT NULL,
  `service_id` int(8) NOT NULL,
  `part_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `status` varchar(100) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_parts`
--

INSERT INTO `device_parts` (`id`, `service_id`, `part_name`, `description`, `price`, `status`, `date`) VALUES
(3, 1, 'Front LED Panel', 'Backlight was not working.', '1200.00', '', '2018-10-05'),
(4, 1, 'Motherboard Heat sink module', 'Module was old and not working', '250.00', '', '2018-10-05'),
(5, 3, 'Power socket', 'Power source is not working', '480.23', '', '2018-10-05'),
(10, 9, 'Motherboard Heat sink module', 'Module memory', '1000.00', 'PAID', '2018-10-07'),
(11, 9, 'Power socket', 'Power source is not working', '480.23', '', '2018-10-07');

-- --------------------------------------------------------

--
-- Table structure for table `engineers`
--

CREATE TABLE `engineers` (
  `id` int(8) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `date_of_joining` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `engineers`
--

INSERT INTO `engineers` (`id`, `name`, `address`, `date_of_joining`) VALUES
(6, 'Gaurav Sharma', '555 Main Street', '2018-09-28'),
(14, 'Mohan Kumar', '123 noida', '2018-09-30'),
(15, 'Rajiv Mohan', '123 appartment noida', '2018-10-04'),
(16, 'Ompal Gupta', '44 morta, sector 28 noida', '2018-10-04'),
(18, 'John Smith', '123 appartment noida', '2018-10-04'),
(19, 'Bindal Singh', '333 street delhi', '2018-10-04');

-- --------------------------------------------------------

--
-- Table structure for table `engineers_expertise`
--

CREATE TABLE `engineers_expertise` (
  `device_category_id` int(8) NOT NULL,
  `engineer_id` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `engineers_expertise`
--

INSERT INTO `engineers_expertise` (`device_category_id`, `engineer_id`) VALUES
(9, 6),
(11, 6),
(5, 14),
(9, 15),
(11, 15),
(5, 16),
(6, 16),
(3, 18),
(4, 18),
(5, 18),
(6, 18),
(9, 18),
(11, 18),
(3, 19),
(4, 19),
(6, 19);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(8) NOT NULL,
  `type` varchar(100) NOT NULL,
  `device_id` int(8) NOT NULL,
  `alternative_address` varchar(255) NOT NULL,
  `alternative_phone` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `engineer_id` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `duration` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `requested_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `type`, `device_id`, `alternative_address`, `alternative_phone`, `description`, `engineer_id`, `price`, `duration`, `status`, `requested_date`) VALUES
(1, 'fault_repair', 4, '', '', 'Freezer not cooling Ice.', 18, '100.00', 0, 'PAID', '2018-09-29'),
(3, 'fault_repair', 1, '', '', 'Screen is broken', 18, '500.00', 0, 'PAID', '2018-10-01'),
(4, 'fault_repair', 4, '', '', 'Cooling issue in freezer', 18, '1200.00', 0, 'APPROVED', '2018-10-01'),
(5, 'fault_repair', 3, '', '', 'Power supply is not working', 0, '0.00', 0, 'REQUESTED', '2018-10-04'),
(6, 'maintenance', 1, '', '', 'Maintenance service required for 4 years', 0, '1000.00', 1, 'REQUESTED', '2018-10-04'),
(7, 'maintenance', 4, '', '', 'I want this to be serviced', 0, '1000.00', 1, 'REQUESTED', '2018-10-06'),
(8, 'maintenance', 1, '', '', 'Not working fine', 18, '1000.00', 1, 'PAID', '2018-10-06'),
(9, 'maintenance', 1, '', '', 'well, i have not special request', 0, '1000.00', 5, 'APPROVED', '2018-10-07'),
(10, 'fault_repair', 5, '', '', 'dryer not working\r\n', 0, '0.00', 0, 'REQUESTED', '2018-10-11'),
(11, 'maintenance', 6, '', '', 'please send me bill, i will pay you.', 0, '1000.00', 1, 'REQUESTED', '2018-10-11'),
(12, 'maintenance', 3, '', '', 'i need this as soon as possible, starting today', 0, '1000.00', 3, 'REQUESTED', '2018-10-11');

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_category`
--
ALTER TABLE `device_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `device_parts`
--
ALTER TABLE `device_parts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `engineers`
--
ALTER TABLE `engineers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `device_category`
--
ALTER TABLE `device_category`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `device_parts`
--
ALTER TABLE `device_parts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `engineers`
--
ALTER TABLE `engineers`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

